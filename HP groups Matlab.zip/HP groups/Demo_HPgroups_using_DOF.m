%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Authors: Tan-Binh Phan, Dinh-Hoan Trinh, Christian Daul, Didier Wolf   %
%  Contact: tan-binh.phan@univ-lorraine.fr                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Dense Optical Flow for determination of HP-Groups (groups of homologous point)
%%
clc
clear all
close all
%% Add Paths
path_to_OFcode = 'path to the OF_CODE folder containing optical flow code';
addpath(path_to_OFcode);% Other way: setpath to the OF_CODE folder.

addpath(genpath('.\HP_groups'));
image_path = '.\Data_demo';
% Parameter for determination of homologous points
format_images = '*.png'; 
images = Read_images(image_path,format_images); 
[M,N,C] = size(images{1});
pg.tau = 2*M*N/3; pg.epsilon = 0.9; pg.h = 10;

%% Groups of homologous point determination
[HP_groups,vSet] = Generate_HP(image_path,format_images,pg);

%% Visualization a group
% num = 6000;
% for i = 1:length(HP_groups(num).ViewIds)
%     subplot(3,3,i)
%     imshow(images{HP_groups(num).ViewIds(i)});
%     hold on
%     plot(HP_groups(1,num).Points(i,1),HP_groups(1,num).Points(i,2), 'r+', 'LineWidth', 2, 'MarkerSize', 10);
% end