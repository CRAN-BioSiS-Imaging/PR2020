The Code was tested on MATLAB R2018a, Windows 64bit.

Input: The set of images
Output: The groups of homologous point (HP-groups)

First of all, have to download optical flow code (OF_CODE) and setpath to the folder containing it.

I) The parameters
The parameter for group of homologous points determination 
epsilon = 0.1 is the threshold for accurate correspondence (epsilon can be selected from 0.1 to 0.9)
Tau = 2*W*H/3 where WH be the size of image
h = 10 is the grid size

II) Functions (the detailed format of input and output can be seen inside the scripts)

- To compute the optical flow between two images, using the script tvFlow_calc.m
- To compute the reference images can use the script Reference_images.m
- The set of overlapping regions with an arbitrary image can be found by using find_overlapping_regions.m
- To crop the overlapping region between reference image I_k^{ref} and each image I_j belongs to the set of overlapping images with I_{k}^{ref},
  using script Crop_Ovverlapping.m : the out put are the two sub-images of overlapping region extracted from I_k^{ref} and I_j.
- The implementation of inaccurate mask and specular reflection mask can be found in Mask_SR.m and Mask_inac.m
- To determine the homologous point groups, using function Generate_HP.m
See the inside of each function to know the detail.

III) Step by step of the proposed method
-Step 1: Computing OF forward and backward for each pair of consecutive images. 
-Step 2: For each image, finding the set of overlapping images with it.
-Step 3: Determination of reference images.
-Step 4: For each reference images I_k^{ref}, the HP-groups (the groups of homologous points) can be determined by:
         + Generating the 2D points for I_k^{ref}.
         + Determination of corresponding points between I_k^{ref} and each images I_j belongs to the set of overlapping images with I_{k}^{ref}.
A demo example can be found in main.m