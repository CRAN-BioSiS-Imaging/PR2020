%%
% Written by Dr. Dinh Hoan TRINH
% Email: dinh-hoan.trinh@univ-lorraine.fr
% This code is performed based on the Matlab code of Marius Drulea: http://www.cv.utcluj.ro/optical-flow.html
%%
clc
close all;
clear all;

addpath('./Code');
addpath('./Flow_show');

%% Parameters:
para.lambda = 15; % the weight of the data term
para.pyramid_factor = 0.7; % pyramide scale
para.gamma1 = 3; % parameter gamma1 in reglarization term (for distance) 
para.gamma2 = 5; % parameter gamma1 in reglarization term (for color)
%% other settings:
para.nx = 5; para.ny = para.nx; % the size of non-local propagation window
% 
para.downsample_method = 'bilinear'; % the downsampling method used to build the pyramids
para.upsample_method = 'bicubic'; % method for upsampling the flow
para.downsample_method_for_bf = 'bilinear'; % the downsampling method for the pyramid used to compute the bilateral weights
para.antialiasing_start_level = 3; % perform antialiasing for all the levels higher or equal than the given level; for the other levels do not use antialiasing
% warping settings
para.warps = 5; % the numbers of warps per level
para.warping_method = 'bicubic';
para.max_its = 40; % the number of iterations per warp

%% Read images:
I1 = imread('./Data/I_frame10.png');
I2 = imread('./Data/I_frame11.png');
subplot(1,2,1), imshow(I1), title('Source image');
subplot(1,2,2), imshow(I2), title('Target image');

I1 = double(I1)/255;
I2 = double(I2)/255;

%% read the ground-truth flow
floPath = './Data/flow10.flo';
realFlow = readFlowFile(floPath);
tu = realFlow(:, :, 1);
tv = realFlow(:, :, 2);
tic;

%% call main routine
[flow, Occ_mask] = tvFlow_calc(I1, I2, para);
%[flow] = coarse_to_fine(I1, I2, para);
u = flow(:, :, 1);
v = flow(:, :, 2);

%% evalutate the correctness of the computed flow
% compute the mean end-point error (mepe) and the mean angular error (mang)
UNKNOWN_FLOW_THRESH = 1e9;
[mang, mepe] = flowError(tu, tv, u, v, 0, 0.0, UNKNOWN_FLOW_THRESH);
disp(['Mean end-point error: ', num2str(mepe)]);
disp(['Mean angular error: ', num2str(mang)]);

%% display the flow
%plotFlow(u,v ,I1);
flowImg = uint8(robust_flowToColor(flow));
figure; imshow(flowImg), title('Optical flow');

tg = toc;
disp(['Computational times is ', num2str(tg),' seconds']);
fprintf('\n');